from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.


def feeCollection(request):
    #return HttpResponse("<h1>i will collect the fee from this view</h1>")
    return render(request,"finance/fee-collection.html")


def feeDuesReport(request):
    #return HttpResponse("<h1>i will get fee dues report from this view</h1>")
    return render(request,"finance/fee-dues.html")


def feeCollectionReport(request):
    #return HttpResponse("<h1>i will get the feecollection report from this view</h1>")
    return render(request,"finance/fee-collection-report.html")
