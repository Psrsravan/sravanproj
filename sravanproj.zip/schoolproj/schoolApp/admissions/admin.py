from django.contrib import admin
from admissions.models import student
from admissions.models import Teacher
# Register your models here.

class studentadmin(admin.ModelAdmin):
    list_display=['id','name','fathername','classname','contact']

class TeacherAdmin(admin.ModelAdmin):
    list_display=['id','name','exp','subject','contact']


admin.site.register(student,studentadmin)
admin.site.register(Teacher,TeacherAdmin)
